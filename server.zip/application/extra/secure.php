<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 2018/6/27
 * Time: 19:12
 */
return [
    'token_salt' => 'iiHsERgf266MqOlB'
];