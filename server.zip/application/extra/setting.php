<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 2018/7/1
 * Time: 0:33
 */
return [
    'token_expire_in' => 7200
];