<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 2018/7/10
 * Time: 21:39
 */

namespace app\api\model;


use think\Model;

class Image extends Model
{

}