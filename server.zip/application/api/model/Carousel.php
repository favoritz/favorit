<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 2018/7/10
 * Time: 21:42
 */

namespace app\api\model;

use think\Model;

class Carousel extends Model
{

}