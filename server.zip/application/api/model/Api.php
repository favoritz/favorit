<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 2018/7/7
 * Time: 17:47
 */

namespace app\api\model;

use think\Model;

class Api extends Model
{

}