<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 2018/6/26
 * Time: 8:13
 */

namespace app\api\model;


class BaseModel
{

}