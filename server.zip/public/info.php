<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 2018/6/24
 * Time: 22:54
 */
phpinfo();