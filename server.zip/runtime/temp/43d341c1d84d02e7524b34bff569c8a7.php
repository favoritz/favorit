<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:71:"D:\xampp\htdocs\favorit\public/../application/api\view\index\login.html";i:1529892569;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>返回值</title>
</head>
<body>
    <br><br>
    userid: <?php echo $data['id']; ?><br>
    nickname：<?php echo $data['nickName']; ?><br>
    mobile: <?php echo $data['mobile']; ?><br>
    email: <?php echo $data['email']; ?><br>
    todocount: <?php echo $data['todocount']; ?><br>
    donecount: <?php echo $data['donecount']; ?><br>
</body>
</html>