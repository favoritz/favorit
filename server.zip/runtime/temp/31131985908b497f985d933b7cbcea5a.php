<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:71:"D:\xampp\htdocs\favorit\public/../application/api\view\apilist\api.html";i:1531004313;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php if(is_array($api) || $api instanceof \think\Collection || $api instanceof \think\Paginator): $i = 0; $__LIST__ = $api;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
api编号：<?php echo $vo['id']; ?><br/>
api名称：<?php echo $vo['name']; ?><br/>
http方法:<?php echo $vo['httpmethod']; ?><br/>
调用地址：<?php echo $vo['url']; ?><br/>
参数：<?php echo $vo['params']; ?><br/>
备注：<?php echo $vo['memo']; ?><br/>
---------------------------------------------<br/>


<?php endforeach; endif; else: echo "" ;endif; ?>

</body>
</html>