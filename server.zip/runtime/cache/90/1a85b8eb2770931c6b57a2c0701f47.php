<?php
//000000007200
 exit();?>
s:102:"{"session_key":"CnHTAPyh\/1pAZHC+fCzb7w==","openid":"oVLN_4gqso2CLLI-FOQ0bnOMC1sE","uid":4,"scope":16}";