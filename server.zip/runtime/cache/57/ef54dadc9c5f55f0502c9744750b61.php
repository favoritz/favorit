<?php
//000000000072
 exit();?>
s:101:"{"session_key":"1bravMrjBcrmpz1mrtfGEA==","openid":"oVLN_4gqso2CLLI-FOQ0bnOMC1sE","uid":1,"scope":16}";