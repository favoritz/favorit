<?php
	
	$this->load->database();
	
	$data = array(
		'title' => $title,
		'name' => $name,
		'date' => $date
	);
	
	$this->db->insert->('mytable', $data);